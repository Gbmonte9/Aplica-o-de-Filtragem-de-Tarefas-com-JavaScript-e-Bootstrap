

// ASYNC que quer dizer a Assíncrona ... ou seja ele retorna o resultado assim que for encotrado.
const getJSON = async (caminho) => {
    //1 - Nesse caso criei a const resultado que ira receber o caminho.
    //2 - Await que no caso e a espera da entrega... não importa o tempo que ira demorar
    //3 - Fetch e uma forma de fazer comunicação entre o Servido e o Cliente para fazer entrega
    const resultados = await fetch(caminho);
    // .json() para declara que isso e json.
    const dados = await resultados.json();

    // retornando os dados.
    return dados;

}

const clickLimpa = () => {

    // Faço a Página ser carregado
    window.location.reload();

}

const clickTarefa = () => {
    
    // Peguei os id do radio checked
    //TarefaConcluida
    let tc = document.getElementById("tarefaConcluida");
    //TarefaPedente
    let tp = document.getElementById("tarefaPedente");

    // Caminho da Pagina do JSON
    const caminhoJSON = "https://jsonplaceholder.typicode.com/todos";
    
    // Uma FUNCTION para poder fazer o caminho do JSON + o Caminho
    getJSON(caminhoJSON).then(listaTarefa => {

        // Criei uma let ListaCabecalho para poder recebe os comandos html
        let linhaCabecalho = "<thead><tr><th>IDUSER</th><th>ID</th><th>TITLE</th><th>COMPLETED</th></tr></thead>";

        // Criei duas lista para receber listaConcluida e listaPendentes
        let linhaTableaCM = '';
        let linhaTabelaPM = '';


        // Estou fazendo um if no caso se o radio for clicado
        // Se caso ListaConcluida for Clicado
        if(tc.checked){

            // Criei uma variavel para receber uma lista de Tarefa que estão concluidas através do Flter que ele retorna um boolean.
            const listaConcluida = listaTarefa.filter(listaTarefa => listaTarefa.completed);

            // Usei o forEach para fazer um loop.
            listaConcluida.forEach(lista => {
                // Tudo que estiver concluida guarda.
                linhaTableaCM += `<tbody><tr><td>${lista.userId}</td><td>${lista.id}</td><td>${lista.title}</td><td>${lista.completed}</td></tr></tbody>`;
            });

            // Fazendo com que a tabela receba os resultados.
            document.getElementById("minhaTabela").innerHTML = linhaCabecalho + linhaTableaCM;

        } 
        
        // Se caso listaPendentes for Clicado
        else if(tp.checked){

            // Criei uma variavel para receber uma lista de Tarefa que NÃO estão concluidas através do Flter que ele retorna um boolean.
            const listaPedente = listaTarefa.filter(listaTarefa => !listaTarefa.completed);

            // Usei o forEach para fazer um loop.
            listaPedente.forEach(lista => {
                 // Tudo que estiver concluida guarda.
                linhaTabelaPM += `<tbody><tr><td>${lista.userId}</td><td>${lista.id}</td><td>${lista.title}</td><td>${lista.completed}</td></tr></tbody>`;
            });

            // Fazendo com que a tabela receba os resultados.
            document.getElementById("minhaTabela").innerHTML = linhaCabecalho + linhaTabelaPM;
    
        }
             
    });

}


const init = () => {

    // Pegando o Id dos Botões 
    const btnTarefa = document.getElementById("btnTarefa");
    const btnLimpaPagina = document.getElementById("btnLimpaPagina");

    // Fazendo um evento ao ser Clicado.
    // Tarefa
    btnTarefa.addEventListener('click', clickTarefa);
    // Limpa
    btnLimpaPagina.addEventListener("click", clickLimpa);

}

// DOM para pode carregar a página
document.addEventListener("DOMContentLoaded", init);