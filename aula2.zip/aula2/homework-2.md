# Homework 2

Dando continuidade aos estudos, vocês devem construir uma página HTML com:

- dois botões de rádio com as etiquetas 'Tarefas Completas' e 'Tarefas pendentes';
- uma tabela com 3 colunas: 'ID da tarefa', 'Tarefa' e 'Status';

Para preencher a tabela, você deve ler o arquivo JSON diretamente da URL https://jsonplaceholder.typicode.com/todos usando o método fetch().

Seu código JS deve ter duas funções para filtrar as tarefas através do campo 'completed', que está dentro do arquivo JSON.

O filtro deve entrar em ação quando o usuário clicar em um dos botões de rádio criados acima.

Bons estudos!